##author M.Gnana Prasuna
#importing required modules
from flask import Flask, render_template ,url_for,request,redirect,flash,session,current_app
from flask_mysqldb import MySQL
from flask_bcrypt import Bcrypt
import os
import secrets
#linking with flask
app=Flask(__name__)
mysql=MySQL(app)
bcrypt=Bcrypt(app)
#connecting with database
app.config["SECRET_KEY"]="fdddddddddd"
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'project'
app.config['MYSQL_CURSORCLASS']='DictCursor'
#for saving images
def save_images(photo):
    hash_photo = secrets.token_urlsafe(10)
    file_extention =os.path.splitext(photo.filename)
    photo_name = hash_photo + file_extention[1]
    file_path = os.path.join(current_app.root_path,'static/images',photo_name)#uploading to static folder
    photo.save(file_path)
    return photo_name
#welcome page path
@app.route("/")
def index():


    return render_template("grp_prj_1/welcome.html")

#register path
@app.route("/register",methods=["POST","GET"])
def register():
    if request.method =="POST":#requesting form for data
        fullname = request.form['fullname']
        resume = request.form['resume']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirm_password']
        category=request.form['category']
        if (fullname or resume or email or password or confirm_password) ==' ' :#empty fields
            flash('All fields must be filled','danger')
            return redirect('/')
        if password != confirm_password:#flash message for mismatch of passwords
            flash('passwords doesnt match','danger')
            return redirect('/')
        if category == 'employee':#if user chose employee
            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM employee where name=%s",[fullname])
            data=cur.fetchall()
            if data:#if employee with Same name
                flash('Username already registered','danger')
            else:
                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO employee (name,resume,email,password)" "VALUES(%s,%s,%s,%s)",(fullname,resume,email,bcrypt.generate_password_hash(password)))
                mysql.connection.commit()
                cur.close()
                flash('You have successfully registered','success')
                return redirect('/home')
        if category == 'employer':#if user is employer
            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM employer where name=%s",[fullname])
            data=cur.fetchall()
            if data:#if name exists
                flash('Username already registered','danger')
            else:

                cur = mysql.connection.cursor()
                cur.execute("ALTER TABLE employee ADD COLUMN `%s` varchar(10) NOT NULL" %fullname)#adding employer name column in employee table
                mysql.connection.commit()
                cur.close()

                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO employer (name,resume,email,password)" "VALUES(%s,%s,%s,%s)",(fullname,resume,email,bcrypt.generate_password_hash(password)))#creating employer
                mysql.connection.commit()
                cur.close()

                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO list (emp)" "VALUES(%s)",[fullname])
                mysql.connection.commit()
                cur.close()
                flash('You have successfully registered','success')
                return redirect('/')
    return render_template("grp_prj_1/welcome.html")

#login path
@app.route("/login",methods=["GET","POST"])
def login():
    if request.method =="POST":#requesting form for data
        username = request.form['username']
        password1 = request.form['password']
        category= request.form['category']
        if category =='employee':#if choose employee
            cur = mysql.connection.cursor()
            result=cur.execute("SELECT * FROM employee WHERE name=%s",[username])#searching for name in employee table
            if result>0:
                data=cur.fetchone()
                password=data['password']
                uid = data['id']
                if bcrypt.check_password_hash(password,password1):#if entered password match with password in employee table 
                    session['login'] = True
                    session['resume']=data['resume']
                    session['name']=data['name']
                    session['email']=data['email']
                    session['uid']= uid
        
                    cur.close()
                    cur=mysql.connection.cursor()
                    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
                    user = cur.fetchone()
                    return redirect("/profile")
                    return render_template('grp_prj_1/employee.html',user=user)
                else:#if wrong password
                    flash('Password doesnt match','danger') 
        if category == 'employer':#if chooses employer
            cur = mysql.connection.cursor()
            result=cur.execute("SELECT * FROM employer WHERE name=%s",[username])#search for the name in employer table
            if result>0:
                data=cur.fetchone()
                password=data['password']
                uid = data['id']
                if bcrypt.check_password_hash(password,password1):#checking passwords
                    session['login'] = True
                    session['resume']=data['resume']
                    session['name']=data['name']
                    session['email']=data['email']
                    session['uid']= uid
                    cur.close()
                    return redirect('/employer')
                else:
                    flash('Password doesnt match','danger') 
        else:
            flash('Username is incorrect','danger')
            return redirect('/')

    return render_template("grp_prj_1/welcome.html")

#employer page 
@app.route('/employer',methods=['POST','GET'])
def employer():
    username=session['name']
    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM employer WHERE name=%s",[username])#fetching employer details from employer table
    user = cur.fetchone()

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE `%s`='1'"%username)#cheking for the profiles he can view
    view = cur.fetchall()
    s=0

    if request.method=='POST':
        s=1
        category=request.form['category']
        cur = mysql.connection.cursor()
        cur.execute("SELECT * FROM employee WHERE name=%s",[category])
        emp = cur.fetchone()
    if s>0:#fetching details of employee he can view
        cur=mysql.connection.cursor()
        cur.execute("SELECT * FROM exp WHERE user=%s",[category])
        exe = cur.fetchone()
        cur=mysql.connection.cursor()
        cur.execute("SELECT * FROM qualification WHERE user=%s",[category])
        qual=cur.fetchall()
        cur=mysql.connection.cursor()
        cur.execute("SELECT * FROM qualification WHERE user=%s",[category])
        qua=cur.fetchone()
        cur=mysql.connection.cursor()
        cur.execute("SELECT * FROM list")
        cat=cur.fetchone()
        return render_template("grp_prj_1/employer.html",user=user,view=view,s=s,emp=emp,exe=exe,qual=qual,cat=cat,qua=qua)
    else:
        return render_template("grp_prj_1/employer.html",user=user,view=view)

#employer basic info editing
@app.route('/login/editemployer/<username>',methods=["POST","GET"])
def editemp(username):
    if request.method=="POST":
        username = request.form.get('name')
        email = request.form.get('email')
        resume = request.form.get('resume')
        img = save_images(request.files['img'])
        cur = mysql.connection.cursor()
        cur.execute("UPDATE employer SET name=%s , email=%s,img=%s, resume=%s WHERE name=%s",
            (username,email,img,resume,username))#updating details
        mysql.connection.commit()
        cur.close()
        flash('Your profile updated successfully','success')
        return redirect('/employer')#going back
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employer WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']
    if author == author2:
        return render_template('grp_prj_1/editemployer.html',user=user)

#employee page
@app.route('/profile',methods=["POST","GET"])
def profile():#fetching name of employee who is in session/logged in
    username=session['name']
    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])#fetching details
    user = cur.fetchone()

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM qualification WHERE user=%s",[username])
    qual=cur.fetchall()

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM exp WHERE user=%s",[username])
    exe=cur.fetchone()

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM list")
    cat=cur.fetchall()

    if request.method=='POST':
        view=request.form['view']
        per=request.form['per']
        if per=='grant':#granting view to employer
            cur = mysql.connection.cursor()
            cur.execute("UPDATE employee SET `"+view+"`='1' WHERE name=%s",[username])
            mysql.connection.commit()
            cur.close()
            flash('Viewers updated successfully','success')
            return redirect('/profile')
        if per=='ungrant':#ungranting view to employer
            cur = mysql.connection.cursor()
            cur.execute("UPDATE employee SET "+view+"='0' WHERE name=%s",[username])
            mysql.connection.commit()
            cur.close()
            flash('Viewers updated successfully','success')
            return redirect('/profile')#going back

    return render_template('grp_prj_1/employee.html',user=user,qual=qual,exe=exe,cat=cat)

#employee info editing
@app.route('/login/editinfo/<username>',methods=["POST","GET"])
def editprofile(username):
    if request.method=="POST":
        username = request.form.get('name')#requesting form for details
        email = request.form.get('email')
        resume = request.form.get('resume')
        num = request.form.get('contact')
        address = request.form.get('address')
        img = save_images(request.files['img'])
        cur = mysql.connection.cursor()
        cur.execute("UPDATE employee SET name=%s , email=%s,img=%s, resume=%s,contact=%s,address=%s WHERE name=%s",
            (username,email,img,resume,num,address,username))#updating to our db
        mysql.connection.commit()
        cur.close()
        flash('Your profile updated successfully','success')
        return redirect('/profile')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']
    if author == author2:
        return render_template('grp_prj_1/editemployee.html',user=user)

#employee story editing
@app.route('/login/editstory/<username>',methods=["POST","GET"])
def editstory(username):
    if request.method=="POST":
        name= session['name']
        intro = request.form.get('intro')#requesting form for details
        cur = mysql.connection.cursor()
        cur.execute("UPDATE employee SET intro=%s WHERE name=%s",(intro,username))
        mysql.connection.commit()#updating to db
        cur.close()
        flash('Your profile updated successfully','success')
        return redirect('/profile')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']
    if author == author2:
        return render_template('grp_prj_1/editstory.html',user=user)

#editing employee hobbies and achievements
@app.route('/login/edithobby/<username>',methods=["POST","GET"])
def hobby(username):
    if request.method=="POST":
        name= session['name']
        hob = request.form.get('hobby')#requesting form
        achi = request.form.get('achi')
        cur = mysql.connection.cursor()
        cur.execute("UPDATE employee SET hobby=%s , achi=%s WHERE name=%s",(hob,achi,username))#updating to db
        mysql.connection.commit()
        cur.close()#closing db connection
        flash('Your profile updated successfully','success')
        return redirect('/profile')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']
    if author == author2:
        return render_template('grp_prj_1/edithob.html',user=user)

#employee current work editing
@app.route('/login/currentwork/<username>',methods=["POST","GET"])
def job(username):
    if request.method=="POST":
        name= session['name']
        work = request.form.get('work')
        cur = mysql.connection.cursor()
        cur.execute("UPDATE employee SET work=%s WHERE name=%s",(work,username))#updating to db
        mysql.connection.commit()
        cur.close()
        flash('Your profile updated successfully','success')
        return redirect('/profile')
    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']
    if author == author2:
        return render_template('grp_prj_1/editwork.html',user=user)

#editing employee qualification
@app.route("/login/qualification/<username>",methods=['POST','GET'])
def qual(username):
    if request.method=="POST":
        name= session['name']
        degree = request.form.get('degree')#requesting form for details
        college=request.form.get('college')
        per=request.form.get('per')
        yop=request.form.get('yop')

        cur = mysql.connection.cursor()#making connection with mysql
        qual=cur.execute("SELECT * FROM qualification WHERE user=%s",[username])
        if qual>0:#if qualification already exists under that employee then update the data under that qualification
            cur = mysql.connection.cursor()
            deg=cur.execute("SELECT * FROM qualification WHERE degree=%s",[degree])
            if deg>0:#under qualification if degree Exists then update data under that degree
                cur = mysql.connection.cursor()
                cur.execute("UPDATE qualification SET user=%s , degree=%s ,college=%s,per=%s,yop=%s WHERE user=%s and degree=%s",(name,degree,college,per,yop,name,degree))
                mysql.connection.commit()
                cur.close()
                flash('Your profile updated successfully','success')
                return redirect('/profile')
            else:
                cur = mysql.connection.cursor()
                cur.execute("INSERT INTO qualification (user,degree,college,per,yop)" "VALUES(%s,%s,%s,%s,%s)",(username,degree,college,per,yop))
                mysql.connection.commit()
                cur.close()
                flash('You have successfully registered','success')
                return redirect('/profile')
        else:
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO qualification (user,degree,college,per,yop)" "VALUES(%s,%s,%s,%s,%s)",(username,degree,college,per,yop))
            mysql.connection.commit()
            cur.close()
            flash('You have successfully registered','success')
            return redirect('/profile')

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM degree ORDER By id DESC")
    cat = cur.fetchall()#for degrees list

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM qualification WHERE user=%s",[username])
    qual = cur.fetchall()

    if author == author2:
        return render_template('grp_prj_1/editqual.html',user=user,cat=cat,qual=qual)

#editing employee experience
@app.route("/login/experiance/<username>",methods=['POST','GET'])
def experiance(username):
    if request.method=="POST":
        name= session['name']
        exp1 = request.form.get('exp1')#requesting form for data
        exp2=request.form.get('exp2')
        exp3=request.form.get('exp3')
        cur = mysql.connection.cursor()
        ex=cur.execute("SELECT * FROM exp WHERE user=%s",[username])
        if ex>0:#if experience exists update data
            cur = mysql.connection.cursor()
            cur.execute("UPDATE exp SET user=%s , exp1=%s ,exp2=%s,exp3=%s WHERE user=%s",(username,exp1,exp2,exp3,username))
            mysql.connection.commit()
            cur.close()
            flash('Your profile updated successfully','success')
            return redirect('/profile')
        else:#else create experience and insert
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO exp (user,exp1,exp2,exp3)" "VALUES(%s,%s,%s,%s)",(username,exp1,exp2,exp3))
            mysql.connection.commit()
            cur.close()
            flash('You have successfully registered','success')
            return redirect('/profile')

    cur = mysql.connection.cursor()
    cur.execute("SELECT * FROM employee WHERE name=%s",[username])
    user = cur.fetchone()
    author = user['name']
    author2 = session['name']

    cur=mysql.connection.cursor()
    cur.execute("SELECT * FROM exp WHERE user=%s",[username])
    exe = cur.fetchall()

    if author == author2:
        return render_template('grp_prj_1/editexe.html',user=user,exe=exe)


#loggin out

@app.route("/logout")
def logout():
    session.clear()
    flash('You are logged out','success')
    return redirect("/login")

#for automatic run 
if __name__=="__main__":
    
    app.run(debug=True)
