﻿#Set-Location -Path "E:\scripts"
# Define server settings'
$imapServer = "imap.gmail.com"                # IMAP server
$email = "prasunaaarohi@gmail.com"            # Your email address
$password = "jxuy pxlt teve jbjt"             # Your app password if using Gmail
$port = 993                                   # IMAP SSL port
$useSsl = $true                               # SSL is true for secure connection
$specificSender = "+16825548600@tmomail.net"  # Replace with the specific sender's email
Add-Type -Path "C:\Windows\System32\AE.Net.Mail\lib\net45\AE.Net.Mail.dll"

#Add-Type -Path "C:\Program Files\PackageManagement\NuGet\Packages\AE.Net.Mail.1.7.10.0\lib\net45\AE.Net.Mail.dll"
$weekstart=(Get-Date).AddDays(-([int](Get-Date).DayOfWeek - 1))
$status= (Get-Content -Path E:\scripts\B_cleaning.txt).Split(",")
$cleaner=("vaishu","prasu","urekha")

try {
    # Create an IMAP client and connect
    $client = New-Object AE.Net.Mail.ImapClient($imapServer, $email, $password, "Login", $port, $useSsl)
    Write-Output "Connected to IMAP server successfully."

    # Select the INBOX mailbox
    $client.SelectMailbox("cleanedB")
    Write-Output "Selected the INBOX."

    $count=$client.GetMessageCount()
    if($count -ge 1){
        $messages=($client.GetMessages($count-1,$count))
        $date=$messages.date
        if($date -ge $weekstart){
            if($cleaner.IndexOf($status[1])+1 -ge $cleaner.Count){
                $next=$cleaner[0]
            }
            else{
            $next= $cleaner[$cleaner.IndexOf($status[1])+1]
            }
            $content= "cleaned,"+$next
            Set-Content -Path "E:\scripts\B_cleaning.txt" -Value $content
            Add-Content -Path "E:\scripts\logB.txt" -Value "$(Get-Date): File updated successfully."
        }
    }
    else{
        Add-Content -Path "E:\scripts\logB.txt" -Value "$(Get-Date): Room not cleaned , hence file not updated"
    }

} 
catch {
    Write-Output "Error connecting to IMAP server: $_"
    Add-Content -Path "E:\scripts\log.txt" -Value "$(Get-Date): Error - $_"
}
