﻿# Define variables
$SMTPServer = "smtp.gmail.com"   # e.g., smtp.gmail.com for Gmail
$SMTPPort = 587                                # Common port for SMTP with TLS
$Username = "prasunaaarohi@gmail.com"            # Your email address
$Password = "jxuy pxlt teve jbjt"                # Your email password
$From = "prasunaaarohi@gmail.com"                # The sender's email (your email)
$To= "prasunaaarohi@gmail.com","tulasinagaboina@gmail.com","Vaishnavipalle12@gmail.com","urekha0524@gmail.com"
#$To = "6825548600@tmomail.net","2144756556@tmomail.net","6823919899@tmomail.net","6825547720@tmomail.net" # Recipient’s phone number with carrier SMS gateway domain
$Subject = "Common Area cleaning Details"
#$Body = "Hello! This is a test SMS sent from PowerShell via email-to-SMS."
$cleaner=("a","vaishu","Room a","prasu","A","urekha")
# Create secure string for password
$SecurePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
$Credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $Username, $SecurePassword

$status= (Get-Content -Path E:\scripts\room_cleaning.txt).Split(",")
if($status[0] -eq "cleaned"){  
    #$next= $cleaner[$cleaner.IndexOf($status[1])+1]
    $Body="Common area cleaning for the next week -"+$status[1]
    Send-MailMessage -From $From -To $To -Subject $Subject -Body $Body -SmtpServer $SMTPServer -Port $SMTPPort -Credential $Credential -UseSsl

    if((Get-Date).DayOfWeek -eq "Tuesday"){
        $content="Not cleaned,"+$status[1]
        Set-Content -Path E:\scripts\room_cleaning.txt -Value $content
    }
}
else{
    # Send email
    $date= (Get-Date).ToShortDateString()
    $Body="Common area cleaning for this week "+$date+" --> " +$status[1]+" .If cleaning is completed please SMS cleaned to the sender: prasunaaarohi@gmail.com from your mobile"
    Send-MailMessage -From $From -To $To -Subject $Subject -Body $Body -SmtpServer $SMTPServer -Port $SMTPPort -Credential $Credential -UseSsl

}
